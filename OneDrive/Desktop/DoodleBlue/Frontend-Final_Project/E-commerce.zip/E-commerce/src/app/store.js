
// import { configureStore } from "@reduxjs/toolkit";
// import {
//   persistStore,
//   persistReducer,
//   FLUSH,
//   REHYDRATE,
//   PAUSE,
//   PERSIST,
//   PURGE,
//   REGISTER,
// } from "redux-persist";

// import cartReducer from "../features/cart/cartSlice";
// import productsReducer from "../features/products/productsSlice";

// // Browser localStorage adapter
// const storage = {
//   getItem: (key) =>
//     Promise.resolve(window.localStorage.getItem(key)),

//   setItem: (key, value) =>
//     Promise.resolve(window.localStorage.setItem(key, value)),

//   removeItem: (key) =>
//     Promise.resolve(window.localStorage.removeItem(key)),
// };

// const persistConfig = {
//   key: "shopkart-cart",
//   version: 1,
//   storage,
// };

// const persistedCartReducer = persistReducer(
//   persistConfig,
//   cartReducer
// );

// export const store = configureStore({
//   reducer: {
//     cart: persistedCartReducer,
//     products: productsReducer,
//   },

//   middleware: (getDefaultMiddleware) =>
//     getDefaultMiddleware({
//       serializableCheck: {
//         ignoredActions: [
//           FLUSH,
//           REHYDRATE,
//           PAUSE,
//           PERSIST,
//           PURGE,
//           REGISTER,
//         ],
//       },
//     }),
// });

// export const persistor = persistStore(store);



import { configureStore } from "@reduxjs/toolkit";

import productsReducer from "../features/products/productsSlice";
import cartReducer from "../features/cart/cartSlice";

export const store = configureStore({
  reducer: {
    products: productsReducer,
    cart: cartReducer,
  },
});
