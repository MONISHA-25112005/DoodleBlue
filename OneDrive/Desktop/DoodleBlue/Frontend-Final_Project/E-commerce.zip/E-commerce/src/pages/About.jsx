
function About() {
  return (
    <section className="page-container">
      <h1>About ShopKart</h1>

      <p>
        ShopKart is a React e-commerce training project built
        with Redux Toolkit, Context API and React Router.
      </p>

      <p>
        Explore meals, manage your cart, save favorites and
        place demo orders.
      </p>

      <p>
        Meal information comes from TheMealDB. Prices are
        generated demo values because this API does not provide
        actual selling prices.
      </p>
    </section>
  );
}

export default About;
