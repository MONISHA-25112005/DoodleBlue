
import { Link } from "react-router-dom";
import { useShop } from "../context/ShopContext";
import ProductCard from "../components/ProductCard";

function Favorites() {
  const { favorites } = useShop();

  return (
    <section className="page-container">
      <h1>My Favorite Meals</h1>
      <p>{favorites.length} favorite meals</p>

      {favorites.length === 0 ? (
        <>
          <p>You haven't added any favorites yet.</p>
          <Link to="/">Explore Meals</Link>
        </>
      ) : (
        <div className="product-grid">
          {favorites.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
            />
          ))}
        </div>
      )}
    </section>
  );
}

export default Favorites;
