
// import { Link } from "react-router-dom";
// import { useDispatch, useSelector } from "react-redux";

// import {
//   increase,
//   decrease,
//   removeFromCart,
//   clearCart,
//   selectTotalItems,
//   selectTotalPrice,
// } from "../features/cart/cartSlice";

// import { useShop } from "../context/ShopContext";

// function Cart() {
//   const dispatch = useDispatch();

//   const items = useSelector((state) => state.cart.items);
//   const totalItems = useSelector(selectTotalItems);
//   const subtotal = useSelector(selectTotalPrice);

//   const { placeOrder } = useShop();

//   const shipping =
//     subtotal >= 100 ? 0 : items.length > 0 ? 5 : 0;

//   const total = subtotal + shipping;

//   function handleOrder() {
//     placeOrder(items, total);
//     dispatch(clearCart());
//     window.alert("Your demo order has been placed!");
//   }

//   if (items.length === 0) {
//     return (
//       <section className="page-container empty-cart">
//         <h1>Your Cart Is Empty</h1>
//         <p>Browse meals and add your favourites to the cart.</p>
//         <Link to="/">Browse Products</Link>
//       </section>
//     );
//   }

//   return (
//     <section className="page-container">
//       <h1>Your Cart ({totalItems} items)</h1>

//       <button
//         type="button"
//         onClick={() => dispatch(clearCart())}
//       >
//         Clear Cart
//       </button>

//       <div className="cart-layout">
//         <div>
//           {items.map((item) => (
//             <article className="cart-item" key={item.id}>
//               {item.image && (
//                 <img src={item.image} alt={item.title} />
//               )}

//               <div className="cart-item-info">
//                 <h3>{item.title}</h3>
//                 <p>₹{Number(item.price).toFixed(2)} each</p>

//                 <div className="quantity-controls">
//                   <button
//                     type="button"
//                     onClick={() => dispatch(decrease(item.id))}
//                   >
//                     −
//                   </button>

//                   <span className="quantity">
//                     {item.quantity}
//                   </span>

//                   <button
//                     type="button"
//                     onClick={() => dispatch(increase(item.id))}
//                   >
//                     +
//                   </button>
//                 </div>

//                 <p>
//                   Line total: ₹
//                   {(item.price * item.quantity).toFixed(2)}
//                 </p>

//                 <button
//                   type="button"
//                   onClick={() =>
//                     dispatch(removeFromCart(item.id))
//                   }
//                 >
//                   Remove
//                 </button>
//               </div>
//             </article>
//           ))}
//         </div>

//         <aside className="order-summary">
//           <h2>Order Summary</h2>

//           <p>Items: {totalItems}</p>
//           <p>Subtotal: ₹{subtotal.toFixed(2)}</p>

//           <p>
//             Shipping:{" "}
//             {shipping === 0
//               ? "FREE"
//               : `₹${shipping.toFixed(2)}`}
//           </p>

//           <h3>Total: ₹{total.toFixed(2)}</h3>

//           <button type="button" onClick={handleOrder}>
//             Place Order
//           </button>
//         </aside>
//       </div>
//     </section>
//   );
// }

// export default Cart;




import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  items: [],
};

const cartSlice = createSlice({
  name: "cart",
  initialState,

  reducers: {
    // Add food to cart
    addToCart: (state, action) => {
      const product = action.payload;

      const existingItem = state.items.find(
        (item) => String(item.id) === String(product.id)
      );

      if (existingItem) {
        existingItem.quantity += 1;
      } else {
        state.items.push({
          ...product,
          price: Number(product.price) || 0,
          quantity: 1,
        });
      }
    },

    // Increase quantity
    increaseQuantity: (state, action) => {
      const item = state.items.find(
        (item) => String(item.id) === String(action.payload)
      );

      if (item) {
        item.quantity += 1;
      }
    },

    // Decrease quantity; remove when quantity reaches zero
    decreaseQuantity: (state, action) => {
      const item = state.items.find(
        (item) => String(item.id) === String(action.payload)
      );

      if (item) {
        if (item.quantity > 1) {
          item.quantity -= 1;
        } else {
          state.items = state.items.filter(
            (item) => String(item.id) !== String(action.payload)
          );
        }
      }
    },

    // Remove one food completely
    removeFromCart: (state, action) => {
      state.items = state.items.filter(
        (item) => String(item.id) !== String(action.payload)
      );
    },

    // Clear the entire cart
    clearCart: (state) => {
      state.items = [];
    },
  },
});

export const {
  addToCart,
  increaseQuantity,
  decreaseQuantity,
  removeFromCart,
  clearCart,
} = cartSlice.actions;

// Selectors
export const selectCartItems = (state) => state.cart.items;

export const selectTotalItems = (state) =>
  state.cart.items.reduce(
    (total, item) => total + item.quantity,
    0
  );

export const selectTotalPrice = (state) =>
  state.cart.items.reduce(
    (total, item) => total + item.price * item.quantity,
    0
  );

export default cartSlice.reducer;
