
// import { useEffect, useState } from "react";
// import { useDispatch, useSelector } from "react-redux";

// import { fetchProducts } from "../features/products/productsSlice";
// import ProductCard from "../components/ProductCard";

// function Home() {
//   const dispatch = useDispatch();

//   const {
//     items: products,
//     status,
//     error,
//   } = useSelector((state) => state.products);

//   const [search, setSearch] = useState("chicken");

//   useEffect(() => {
//     dispatch(fetchProducts("chicken"));
//   }, [dispatch]);

//   function handleSearch(event) {
//     event.preventDefault();
//     dispatch(fetchProducts(search.trim() || "chicken"));
//   }

//   function handleRetry() {
//     dispatch(fetchProducts(search.trim() || "chicken"));
//   }

//   return (
//     <section className="page-container">
//       <h1>All Products</h1>
//       <p>Discover delicious meals on ShopKart.</p>

//       <form
//         onSubmit={handleSearch}
//         className="search-form"
//       >
//         <input
//           type="search"
//           value={search}
//           onChange={(event) => setSearch(event.target.value)}
//           placeholder="Search meals, e.g. chicken..."
//           aria-label="Search meals"
//         />

//         <button type="submit" disabled={status === "loading"}>
//           Search
//         </button>
//       </form>

//       {status === "loading" && (
//         <p className="loading-message">
//           Loading delicious meals...
//         </p>
//       )}

//       {status === "failed" && (
//         <div className="error-message">
//           <p>{error}</p>
//           <button type="button" onClick={handleRetry}>
//             Try Again
//           </button>
//         </div>
//       )}

//       {status === "succeeded" && products.length === 0 && (
//         <p>
//           No meals found. Try searching for chicken, pasta,
//           salmon or curry.
//         </p>
//       )}

//       {status === "succeeded" && products.length > 0 && (
//         <>
//           <p>{products.length} meals found</p>

//           <div className="product-grid">
//             {products.map((product) => (
//               <ProductCard
//                 key={product.id}
//                 product={product}
//               />
//             ))}
//           </div>
//         </>
//       )}
//     </section>
//   );
// }

// export default Home;




import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchProducts } from "../features/products/productsSlice";
import ProductCard from "../components/ProductCard";

function Home() {
  const dispatch = useDispatch();

  const { items, status, error } = useSelector(
    (state) => state.products
  );

  const [search, setSearch] = useState("chicken");

  useEffect(() => {
    dispatch(fetchProducts("chicken"));
  }, [dispatch]);

  function handleSearch(e) {
    e.preventDefault();

    const query = search.trim();

    if (query) {
      dispatch(fetchProducts(query));
    }
  }

  return (
    <main className="page-container">
      <h1>ShopKart Foods</h1>
      <p>Discover delicious meals for your day!</p>

      <form onSubmit={handleSearch} className="search-form">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search foods..."
        />

        <button type="submit">Search</button>
      </form>

      {status === "loading" && (
        <p>Loading foods...</p>
      )}

      {status === "failed" && (
        <div>
          <p>{error}</p>
          <button onClick={() => dispatch(fetchProducts(search))}>
            Retry
          </button>
        </div>
      )}

      {status === "succeeded" && items.length === 0 && (
        <p>No foods found. Try another search.</p>
      )}

      {status === "succeeded" && items.length > 0 && (
        <div className="product-grid">
          {items.map((food) => (
            <ProductCard key={food.id} product={food} />
          ))}
        </div>
      )}
    </main>
  );
}

export default Home;
