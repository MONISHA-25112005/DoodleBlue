
import { useShop } from "../context/ShopContext";

function Orders() {
  const { orders } = useShop();

  return (
    <section className="page-container">
      <h1>My Orders</h1>

      {orders.length === 0 ? (
        <p>No orders placed yet.</p>
      ) : (
        orders.map((order) => (
          <article className="cart-item" key={order.id}>
            <h3>Order #{order.id}</h3>
            <p>Date: {order.date}</p>
            <p>Status: {order.status}</p>
            <p>Total: ₹{order.total.toFixed(2)}</p>

            <p>
              Meals:{" "}
              {order.items
                .map((item) => `${item.title} × ${item.quantity}`)
                .join(", ")}
            </p>
          </article>
        ))
      )}
    </section>
  );
}

export default Orders;
