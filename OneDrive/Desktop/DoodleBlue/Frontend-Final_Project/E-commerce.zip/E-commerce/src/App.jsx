
import { Link, Routes, Route } from "react-router-dom";

import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import ProductDetails from "./pages/ProductDetails";
import Cart from "./pages/Cart";
import Favorites from "./pages/Favorites";
import About from "./pages/About";
import Orders from "./pages/Orders";

import "./app.css";

function App() {
  return (
    <>
      <Navbar />

      <main>
        <Routes>
          {/* Home / Product Listing */}
          <Route path="/" element={<Home />} />

          {/* Individual Meal Details */}
          <Route
            path="/product/:id"
            element={<ProductDetails />}
          />

          {/* Shopping Cart */}
          <Route path="/cart" element={<Cart />} />

          {/* Favorite Meals */}
          <Route
            path="/favorites"
            element={<Favorites />}
          />

          {/* Order History */}
          <Route path="/orders" element={<Orders />} />

          {/* About Page */}
          <Route path="/about" element={<About />} />

          {/* Page Not Found */}
          <Route
            path="*"
            element={
              <section className="page-container not-found">
                <h2>404 - Page Not Found</h2>
                <p>
                  The page you are looking for does not exist.
                </p>
                <Link to="/">Back to Home</Link>
              </section>
            }
          />
        </Routes>
      </main>

      <footer className="footer">
        ShopKart · E-commerce training project
      </footer>
    </>
  );
}

export default App;
