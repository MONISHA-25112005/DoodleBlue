
import { Link, NavLink } from "react-router-dom";
import { useSelector } from "react-redux";
import { selectTotalItems } from "../features/cart/cartSlice";
import { useShop } from "../context/ShopContext";

function Navbar() {
  const cartCount = useSelector(selectTotalItems);
  const { showImages, setShowImages } = useShop();

  return (
    <header className="navbar">
      <Link to="/" className="logo">
        ShopKart
      </Link>

      <nav className="nav-links">
        <NavLink to="/" end>Home</NavLink>
        <NavLink to="/favorites">Favorites</NavLink>
        <NavLink to="/orders">Orders</NavLink>
        <NavLink to="/about">About</NavLink>
        <NavLink to="/cart" className="cart-link">
          Cart ({cartCount})
        </NavLink>
      </nav>

      <button
        type="button"
        className="image-toggle"
        onClick={() => setShowImages((current) => !current)}
      >
        {showImages ? "Hide Images" : "Show Images"}
      </button>
    </header>
  );
}

export default Navbar;
